#!/bin/bash

# 关山智能系统启动脚本 - 绕过VPN代理

# 清理环境变量中的代理设置
unset http_proxy
unset https_proxy
unset HTTP_PROXY
unset HTTPS_PROXY
unset ALL_PROXY
unset all_proxy

# 设置内网绕过
export NO_PROXY="192.168.0.3,localhost,127.0.0.1,192.168.0.0/24,::1"
export no_proxy="192.168.0.3,localhost,127.0.0.1,192.168.0.0/24,::1"

echo "🔧 已清理代理环境变量"
echo "✅ NO_PROXY 已设置为: $NO_PROXY"

# 停止旧进程
echo "🛑 停止旧进程..."
lsof -ti:8000 | xargs kill -9 2>/dev/null
pkill -f "uvicorn src.main:app" 2>/dev/null
sleep 2

# 启动服务
echo "🚀 启动服务..."
cd /Users/lanxionggao/Documents/guanshanPython
nohup python -m uvicorn src.main:app --reload --host 0.0.0.0 --port 8000 > server.log 2>&1 &
echo $! > server.pid

sleep 3

if [ -f server.pid ] && ps -p $(cat server.pid) > /dev/null 2>&1; then
    echo "✅ 后端服务已启动，PID: $(cat server.pid)"
    echo "📊 查看日志: tail -f server.log"
else
    echo "❌ 服务启动失败，请检查日志"
fi
