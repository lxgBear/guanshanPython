# crawl_website 时间范围功能分析报告

**日期**: 2025-11-06
**分析目标**: 确定 `crawl_website` 任务类型是否支持时间范围过滤
**结论**: ❌ **当前不支持**，Firecrawl Crawl API 不提供时间过滤功能

---

## 执行摘要

经过全面的代码分析和 Firecrawl API 文档调研，确认：

1. ✅ **search_keyword 模式**：已支持时间范围过滤（`time_range` 参数）
2. ❌ **crawl_website 模式**：不支持时间范围过滤（Firecrawl Crawl API 限制）
3. 💡 **可行方案**：通过后端元数据过滤或使用 Search API 替代实现需求

---

## 详细分析

### 1. crawl_website 当前实现

#### 1.1 爬取配置参数 (`crawl_config`)

**代码位置**: `src/infrastructure/crawlers/firecrawl_adapter.py:114-178`

**支持的参数**:
```python
{
    "limit": 100,              # 最大页面数
    "max_depth": 3,            # 爬取深度
    "include_paths": [],       # 包含的路径模式
    "exclude_paths": [],       # 排除的路径模式
    "only_main_content": True, # 只提取主内容
    "wait_for": 1000,          # 页面等待时间
    "exclude_tags": []         # 排除的HTML标签
}
```

#### 1.2 Firecrawl Crawl API 参数

**官方文档**: https://docs.firecrawl.dev/features/crawl

**API v2 参数**:
- `url`: 起始URL
- `limit`: 最大爬取页面数
- `max_discovery_depth`: 爬取深度
- `include_paths`: 路径包含模式
- `exclude_paths`: 路径排除模式
- `scrape_options`: 爬取选项（格式、内容清理等）
- `poll_interval`: 轮询间隔
- `timeout`: 超时时间

**❌ 不支持的参数**:
- ❌ `tbs`: 时间范围过滤（仅 Search API 支持）
- ❌ `from_date` / `to_date`: 日期范围
- ❌ `maxAge` 的作用是**缓存控制**，不是内容过滤

---

### 2. search_keyword 时间过滤实现

#### 2.1 已支持的功能

**代码位置**: `src/infrastructure/search/firecrawl_search_adapter.py:280-293`

**实现代码**:
```python
# 构建请求体时，如果配置了 time_range
if config.get('time_range'):
    body['tbs'] = self._convert_time_range(config['time_range'])

def _convert_time_range(self, time_range: str) -> str:
    """转换时间范围为Firecrawl格式"""
    mapping = {
        "day": "qdr:d",      # 最近一天
        "week": "qdr:w",     # 最近一周
        "month": "qdr:m",    # 最近一个月
        "year": "qdr:y"      # 最近一年
    }
    return mapping.get(time_range, "")
```

#### 2.2 使用方式

**API 请求示例**:
```json
{
  "name": "AI新闻监控",
  "query": "人工智能",
  "task_type": "search_keyword",
  "search_config": {
    "limit": 10,
    "time_range": "week"    // 只搜索最近一周的内容
  }
}
```

**Firecrawl API 参数**:
- **预定义范围**: `qdr:h`, `qdr:d`, `qdr:w`, `qdr:m`, `qdr:y`
- **自定义日期范围**: `cdr:1,cd_min:MM/DD/YYYY,cd_max:MM/DD/YYYY`

---

### 3. 为什么 Crawl API 不支持时间过滤

#### 3.1 API 设计目的不同

| API 类型 | 设计目的 | 使用场景 |
|---------|---------|---------|
| **Search API** | 搜索引擎结果爬取 | 监控关键词、新闻追踪、舆情分析 |
| **Crawl API** | 网站结构爬取 | 网站归档、内容迁移、完整抓取 |

**Crawl API 特点**:
- 通过 sitemap 或递归发现页面
- 按 URL 结构而非内容元数据爬取
- 适用于爬取整个网站或特定路径

**Search API 特点**:
- 通过搜索引擎获取结果
- 可以按发布时间、相关性排序
- 适用于追踪特定主题的最新内容

#### 3.2 技术原理差异

```
Search API 工作流程:
1. 查询搜索引擎 (Google/Bing) → 可应用时间过滤
2. 搜索引擎返回符合条件的URL列表
3. 爬取搜索结果页面

Crawl API 工作流程:
1. 从起始URL开始爬取
2. 提取页面中的所有链接
3. 递归爬取符合 include_paths 的链接
4. ❌ 无法在爬取前知道页面发布时间
```

---

### 4. 元数据可用性分析

#### 4.1 爬取结果包含的时间信息

**代码位置**: `src/infrastructure/crawlers/firecrawl_adapter.py:164-171`

**metadata 字段**:
```python
{
    "article:published_time": "2025-11-06T10:00:00Z",  # 文章发布时间
    "article:modified_time": "2025-11-06T12:00:00Z",   # 修改时间
    "og:published_time": "2025-11-06T10:00:00Z",       # Open Graph发布时间
    "statusCode": 200,
    "sourceURL": "https://example.com/article"
}
```

#### 4.2 可用性评估

| 字段 | 可用性 | 说明 |
|------|--------|------|
| `article:published_time` | ⚠️ 部分可用 | 依赖网站实现 Open Graph 元标签 |
| `article:modified_time` | ⚠️ 部分可用 | 可能不准确（编辑更新会改变） |
| URL 路径日期 | ⚠️ 依赖网站 | `/2025/11/article` 格式，需正则解析 |

**问题**:
1. 不是所有网站都包含结构化的时间元数据
2. 元数据在爬取**后**才能获取，无法减少爬取量
3. 会消耗不必要的 Firecrawl 积分

---

## 解决方案对比

### 方案1: 后端元数据过滤 ⭐ 推荐（简单场景）

**实现方式**:
1. 正常爬取网站（不限时间）
2. 爬取完成后，根据 `article_published_time` 过滤结果
3. 只保存符合时间范围的结果

**优点**:
- ✅ 实现简单，不需要改动 Firecrawl 调用
- ✅ 可以使用精确的日期过滤

**缺点**:
- ❌ 仍会爬取所有页面（浪费积分）
- ❌ 执行时间长（无法提前终止）
- ❌ 依赖网站的元数据质量

**代码示例**:
```python
async def crawl_with_time_filter(url, from_date, to_date):
    # 1. 爬取网站
    results = await firecrawl_adapter.crawl(url, limit=100)

    # 2. 过滤结果
    filtered_results = []
    for result in results:
        pub_time = result.metadata.get('article:published_time')
        if pub_time:
            pub_date = datetime.fromisoformat(pub_time)
            if from_date <= pub_date <= to_date:
                filtered_results.append(result)

    return filtered_results
```

**适用场景**:
- 积分充足的情况
- 网站规模较小（< 100页）
- 需要精确的日期范围控制

---

### 方案2: 使用 Search API + site: 操作符 ⭐⭐ 推荐（高效场景）

**实现方式**:
1. 改用 `search_keyword` 模式
2. 使用 `site:domain.com` 限制搜索范围
3. 配置 `time_range` 参数

**优点**:
- ✅ 原生支持时间过滤（节省积分）
- ✅ 只爬取最新内容
- ✅ 执行速度快

**缺点**:
- ❌ 改变了爬取行为（搜索 vs 递归爬取）
- ❌ 依赖搜索引擎索引（可能不完整）
- ❌ 无法控制爬取深度

**API 请求示例**:
```json
{
  "name": "技术博客最新文章",
  "query": "site:blog.example.com",
  "task_type": "search_keyword",
  "search_config": {
    "limit": 50,
    "time_range": "month",
    "only_main_content": true
  }
}
```

**适用场景**:
- 需要监控网站最新内容
- 积分有限，需要高效爬取
- 网站已被搜索引擎索引

---

### 方案3: 调度频率控制 ⭐⭐⭐ 推荐（标准场景）

**实现方式**:
1. 保持 `crawl_website` 模式不变
2. 通过调整 `schedule_interval` 控制更新频率
3. 依赖增量爬取逻辑（去重）

**优点**:
- ✅ 无需修改现有实现
- ✅ 适合完整网站归档场景
- ✅ 符合 Firecrawl Crawl API 设计意图

**缺点**:
- ❌ 无法精确控制时间范围
- ❌ 可能重复爬取相同内容

**配置示例**:
```json
{
  "name": "每日博客归档",
  "crawl_url": "https://blog.example.com",
  "task_type": "crawl_website",
  "crawl_config": {
    "limit": 50,
    "max_depth": 2
  },
  "schedule_interval": "DAILY"  // 每天爬取一次，自然只获取新内容
}
```

**适用场景**:
- 完整网站归档需求
- 网站更新频率固定
- 不需要精确的时间过滤

---

### 方案4: 混合模式 ⭐⭐⭐ 推荐（灵活场景）

**实现方式**:
1. 根据用户需求智能选择模式
2. 有时间范围要求 → `search_keyword` + `site:`
3. 完整归档需求 → `crawl_website`

**优点**:
- ✅ 兼顾效率和完整性
- ✅ 用户体验最佳

**缺点**:
- ❌ 实现复杂度较高
- ❌ 需要前端支持模式切换

**产品设计**:
```
创建任务页面:
├─ 任务类型: [下拉菜单]
│  ├─ 关键词搜索 (推荐用于监控)
│  ├─ 网站爬取 (推荐用于归档)
│  └─ 单页面爬取
│
└─ 时间范围: [条件显示]
   └─ (仅"关键词搜索"显示)
       ├─ 最近一天
       ├─ 最近一周
       ├─ 最近一个月
       └─ 最近一年
```

---

## 推荐方案总结

### 短期方案（无需开发）

**使用 search_keyword + site: 实现时间过滤**

1. 创建任务时选择 `search_keyword` 模式
2. 在 query 中使用 `site:domain.com` 限定域名
3. 配置 `time_range` 参数

**示例**:
```bash
curl -X POST http://localhost:8000/api/v1/search-tasks \
  -H "Content-Type: application/json" \
  -d '{
    "name": "技术博客最新文章",
    "query": "site:blog.example.com",
    "task_type": "search_keyword",
    "search_config": {
      "limit": 50,
      "time_range": "week"
    },
    "schedule_interval": "DAILY"
  }'
```

---

### 中期方案（建议开发）

**为 crawl_website 添加后端时间过滤**

**实现步骤**:

1. **扩展 `crawl_config`**:
   ```python
   {
       "limit": 100,
       "max_depth": 2,
       "time_filter": {
           "from_date": "2025-10-01",  # 可选
           "to_date": "2025-11-01",    # 可选
           "fallback_strategy": "keep_all"  # 当缺少元数据时的策略
       }
   }
   ```

2. **修改爬取流程** (`src/services/task_scheduler.py`):
   ```python
   async def execute_crawl_task(task: SearchTask):
       # 1. 爬取网站
       results = await firecrawl_adapter.crawl(...)

       # 2. 应用时间过滤
       if task.crawl_config.get('time_filter'):
           results = filter_by_publish_time(
               results,
               task.crawl_config['time_filter']
           )

       # 3. 保存过滤后的结果
       await save_results(results)
   ```

3. **添加前端支持**:
   ```typescript
   // 任务创建表单
   {
     taskType: 'crawl_website',
     crawlConfig: {
       limit: 100,
       maxDepth: 2,
       timeFilter: {
         enabled: true,
         fromDate: '2025-10-01',
         toDate: '2025-11-01'
       }
     }
   }
   ```

**工作量估算**: 2-3人天

---

### 长期方案（产品优化）

**智能任务类型推荐**

根据用户需求自动推荐最合适的任务类型：

```
用户输入: "我想监控技术博客的最新文章"
系统推荐: search_keyword + site: + time_range
原因: 需要时间过滤，Search API 更高效

用户输入: "归档整个网站内容"
系统推荐: crawl_website
原因: 完整爬取需求，Crawl API 更适合

用户输入: "定期检查官网首页变化"
系统推荐: scrape_url
原因: 单页面监控，Scrape API 最节省积分
```

---

## 技术文档更新建议

### API 文档补充

**`POST /api/v1/search-tasks` 文档**:

```markdown
### crawl_config 参数说明

| 参数 | 类型 | 说明 | 默认值 |
|------|------|------|--------|
| limit | integer | 最大爬取页面数 | 100 |
| max_depth | integer | 爬取深度 | 3 |
| time_filter | object | ⚠️ 实验性功能：后端时间过滤 | null |

⚠️ **时间过滤限制**:
- Firecrawl Crawl API 不原生支持时间过滤
- 后端过滤会爬取所有页面后再筛选（消耗积分）
- 如需高效时间过滤，建议使用 search_keyword 模式

✅ **推荐做法**:
- 监控最新内容 → 使用 `search_keyword` + `time_range`
- 完整网站归档 → 使用 `crawl_website` + 调度频率控制
```

---

## 附录：测试用例

### 测试1: search_keyword 时间过滤

```python
# 测试 search_keyword 的 time_range 功能
async def test_search_with_time_filter():
    task = {
        "name": "测试时间过滤",
        "query": "人工智能",
        "task_type": "search_keyword",
        "search_config": {
            "limit": 10,
            "time_range": "week"
        }
    }

    results = await create_and_execute_task(task)

    # 验证所有结果的发布时间在一周内
    now = datetime.utcnow()
    one_week_ago = now - timedelta(days=7)

    for result in results:
        assert result.published_date >= one_week_ago
```

### 测试2: crawl_website 元数据验证

```python
# 验证 crawl_website 结果包含时间元数据
async def test_crawl_metadata():
    task = {
        "name": "测试元数据",
        "crawl_url": "https://blog.example.com",
        "task_type": "crawl_website",
        "crawl_config": {
            "limit": 10
        }
    }

    results = await create_and_execute_task(task)

    # 统计包含时间元数据的结果比例
    with_time_metadata = 0
    for result in results:
        if result.metadata.get('article:published_time'):
            with_time_metadata += 1

    coverage = with_time_metadata / len(results) * 100
    print(f"时间元数据覆盖率: {coverage}%")
```

---

## 总结

### 关键要点

1. ❌ **crawl_website 不支持时间范围过滤**
   - Firecrawl Crawl API 的设计限制
   - 爬取时无法预知页面发布时间

2. ✅ **search_keyword 已支持时间过滤**
   - 通过 `time_range` 参数实现
   - 支持: day, week, month, year

3. 💡 **推荐解决方案**
   - **短期**: 使用 search_keyword + site: 替代
   - **中期**: 实现后端元数据过滤
   - **长期**: 智能任务类型推荐

### 决策建议

**如果用户需求是**:
- ✅ 监控网站最新内容 → 使用 search_keyword + time_range
- ✅ 完整网站归档 → 使用 crawl_website + 调度频率
- ✅ 精确日期范围 → 开发后端过滤功能

---

**报告完成时间**: 2025-11-06
**下次审阅**: 需求确认后更新实现方案
