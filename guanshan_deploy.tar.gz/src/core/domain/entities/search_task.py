"""定时搜索任务实体模型

v1.5.0 ID系统统一：
- ✅ 完全统一使用雪花算法ID（移除UUID fallback）
- ✅ 与其他实体保持一致
- ✅ 简化ID处理逻辑
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any, List

# 导入安全ID生成器
from src.infrastructure.id_generator import generate_string_id


class TaskType(Enum):
    """任务类型枚举"""
    SEARCH_KEYWORD = "search_keyword"        # 关键词搜索模式（Search API + Scrape API 详情页）
    SEARCH_MULTILANG = "search_multilang"    # 多语言搜索模式（Claude 翻译 + 多语言并行搜索）
    CRAWL_WEBSITE = "crawl_website"          # 网站爬取模式（Crawl API 递归爬取整个网站）
    SCRAPE_URL = "scrape_url"                # 单页面爬取模式（Scrape API 爬取单个页面）
    MAP_SCRAPE_WEBSITE = "map_scrape_website"  # Map + Scrape 组合模式（Map API 发现 + 批量Scrape + 时间过滤）


class TaskStatus(Enum):
    """任务状态枚举"""
    ACTIVE = "active"       # 活跃
    PAUSED = "paused"       # 暂停
    FAILED = "failed"       # 失败
    COMPLETED = "completed" # 完成
    DISABLED = "disabled"   # 禁用


class ScheduleInterval(Enum):
    """预定义的调度间隔"""
    HOURLY_1 = ("HOURLY_1", "0 * * * *", "每小时", 60, "每小时执行一次")
    HOURLY_6 = ("HOURLY_6", "0 */6 * * *", "每6小时", 360, "每6小时执行一次（0点、6点、12点、18点）")
    HOURLY_12 = ("HOURLY_12", "0 */12 * * *", "每12小时", 720, "每12小时执行一次（0点、12点）")
    DAILY = ("DAILY", "0 9 * * *", "每天", 1440, "每天上午9点执行")
    DAYS_3 = ("DAYS_3", "0 9 */3 * *", "每3天", 4320, "每3天上午9点执行")
    WEEKLY = ("WEEKLY", "0 9 * * 1", "每周", 10080, "每周一上午9点执行")
    
    def __init__(self, enum_value, cron, display_name, minutes, description):
        self.enum_value = enum_value
        self.cron_expression = cron
        self.display_name = display_name
        self.interval_minutes = minutes
        self.description = description
    
    @classmethod
    def from_value(cls, value: str):
        """根据值获取枚举"""
        for interval in cls:
            if interval.enum_value == value:
                return interval
        raise ValueError(f"无效的调度间隔: {value}")
    
    def to_dict(self):
        """转换为字典（用于API响应）"""
        return {
            "value": self.enum_value,
            "label": self.display_name,
            "description": self.description,
            "interval_minutes": self.interval_minutes
        }


def _generate_secure_id() -> str:
    """生成安全的雪花算法ID"""
    return generate_string_id()


@dataclass
class SearchTask:
    """
    搜索任务实体

    v1.5.0 改进：
    - ✅ 统一使用雪花算法ID（移除UUID）
    - ✅ 支持高并发和分布式环境
    - ✅ 全局唯一且不可预测

    v2.0.0 任务类型改进：
    - ✅ 添加 task_type 字段区分任务类型
    - ✅ 支持三种模式：关键词搜索、网站爬取、单页面爬取
    - ✅ 添加 crawl_config 支持 Crawl API 配置
    """
    # 主键（雪花算法ID，全局唯一）
    id: str = field(default_factory=_generate_secure_id)
    name: str = ""
    description: Optional[str] = None

    # 任务类型和目标
    task_type: str = "search_keyword"  # 任务类型：search_keyword, crawl_website, scrape_url, map_scrape_website
    query: str = ""  # 搜索关键词（SEARCH_KEYWORD 模式）
    crawl_url: Optional[str] = None  # 爬取URL（CRAWL_WEBSITE、SCRAPE_URL、MAP_SCRAPE_WEBSITE 模式）
    target_website: Optional[str] = None  # 主要目标网站（用于前端展示，例如：www.gnlm.com.mm）

    # 配置
    search_config: Dict[str, Any] = field(default_factory=dict)  # 搜索配置（JSON）
    crawl_config: Dict[str, Any] = field(default_factory=dict)  # 爬取配置（JSON，用于 CRAWL_WEBSITE 模式）

    # 多语言搜索配置（v2.1.0 新增）
    enable_multilang: bool = False  # 是否启用多语言搜索
    languages: List[str] = field(default_factory=lambda: ["zh"])  # 搜索语言列表（支持: zh, en, ja, ko）
    auto_translate: bool = True  # 是否使用 Claude 自动翻译查询词

    # 调度配置
    schedule_interval: str = "DAILY"  # 调度间隔枚举值
    is_active: bool = True  # 是否启用
    status: TaskStatus = TaskStatus.ACTIVE
    
    # 元数据
    created_by: str = ""  # 创建者
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    last_executed_at: Optional[datetime] = None
    next_run_time: Optional[datetime] = None
    
    # 统计信息
    execution_count: int = 0  # 执行次数
    success_count: int = 0    # 成功次数
    failure_count: int = 0    # 失败次数
    total_results: int = 0    # 总结果数
    total_credits_used: int = 0  # 总消耗积分

    # 错误信息（v2.0.1 新增）
    last_error: Optional[str] = None  # 最后一次执行的错误信息
    last_error_time: Optional[datetime] = None  # 最后一次错误发生时间
    
    def get_task_type(self) -> TaskType:
        """获取任务类型枚举"""
        try:
            return TaskType(self.task_type)
        except ValueError:
            # 默认返回关键词搜索模式
            return TaskType.SEARCH_KEYWORD

    def is_search_keyword_mode(self) -> bool:
        """判断是否为关键词搜索模式"""
        return self.get_task_type() == TaskType.SEARCH_KEYWORD

    def is_crawl_website_mode(self) -> bool:
        """判断是否为网站爬取模式"""
        return self.get_task_type() == TaskType.CRAWL_WEBSITE

    def is_scrape_url_mode(self) -> bool:
        """判断是否为单页面爬取模式"""
        return self.get_task_type() == TaskType.SCRAPE_URL

    def is_map_scrape_mode(self) -> bool:
        """判断是否为 Map + Scrape 组合模式"""
        return self.get_task_type() == TaskType.MAP_SCRAPE_WEBSITE

    def is_multilang_search_mode(self) -> bool:
        """判断是否为多语言搜索模式（v2.1.0 新增）"""
        return self.get_task_type() == TaskType.SEARCH_MULTILANG

    def should_use_multilang(self) -> bool:
        """判断是否应该使用多语言搜索（基于配置自动判断）

        即使 task_type 是 SEARCH_KEYWORD，如果 enable_multilang=True，
        也应该使用多语言执行器
        """
        return self.enable_multilang and len(self.languages) > 0

    def get_schedule_interval(self) -> ScheduleInterval:
        """获取调度间隔枚举"""
        return ScheduleInterval.from_value(self.schedule_interval)

    def update_status(self, new_status: TaskStatus) -> None:
        """更新任务状态"""
        self.status = new_status
        self.updated_at = datetime.utcnow()
    
    def record_execution(self, success: bool, results_count: int = 0, credits_used: int = 0, error_message: Optional[str] = None) -> None:
        """记录执行结果

        Args:
            success: 是否执行成功
            results_count: 结果数量
            credits_used: 消耗的积分
            error_message: 错误信息（仅在失败时提供）
        """
        self.execution_count += 1
        if success:
            self.success_count += 1
            # 成功时清除错误信息
            self.last_error = None
            self.last_error_time = None
        else:
            self.failure_count += 1
            # 失败时记录错误信息
            if error_message:
                self.last_error = error_message
                self.last_error_time = datetime.utcnow()
        self.total_results += results_count
        self.total_credits_used += credits_used
        self.last_executed_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
    
    @property
    def success_rate(self) -> float:
        """计算成功率"""
        if self.execution_count == 0:
            return 0.0
        return (self.success_count / self.execution_count) * 100
    
    @property
    def average_results(self) -> float:
        """计算平均结果数"""
        if self.execution_count == 0:
            return 0.0
        return self.total_results / self.execution_count

    def extract_target_website(self) -> Optional[str]:
        """
        从 search_config 中提取主要目标网站

        Returns:
            主要目标网站域名，如果没有配置则返回 None
        """
        # 防御性编程：确保 search_config 是字典类型
        if not isinstance(self.search_config, dict):
            return None

        include_domains = self.search_config.get('include_domains', [])
        if include_domains and len(include_domains) > 0:
            # 返回第一个域名作为主要目标
            return include_domains[0]
        return None

    def sync_target_website(self) -> None:
        """
        同步 target_website 字段：
        - 如果 target_website 为空，从 search_config 提取
        - 如果 target_website 不为空，保持不变（允许用户自定义）
        """
        if not self.target_website:
            self.target_website = self.extract_target_website()
    
    def get_id_string(self) -> str:
        """获取字符串格式的ID（统一接口，v1.5.0后始终返回雪花ID）"""
        return str(self.id)

    def is_secure_id(self) -> bool:
        """检查是否使用安全的雪花算法ID（v1.5.0后始终返回True）"""
        # 雪花算法ID特征：纯数字且长度在15-19位之间
        return self.id.isdigit() and 15 <= len(self.id) <= 19
    
    @classmethod
    def create_with_secure_id(cls, **kwargs) -> 'SearchTask':
        """
        使用安全ID创建任务实例
        
        Args:
            **kwargs: 其他字段参数
            
        Returns:
            带有安全ID的SearchTask实例
        """
        # 确保使用雪花算法ID
        kwargs.pop('id', None)  # 移除可能存在的id参数
        return cls(id=_generate_secure_id(), **kwargs)
    
    @classmethod
    def migrate_from_unsafe_id(cls, task: 'SearchTask') -> 'SearchTask':
        """
        从不安全ID迁移到安全ID

        Args:
            task: 原始任务实例

        Returns:
            使用安全ID的新任务实例
        """
        # 保持其他字段不变，只替换ID
        new_task = cls(
            id=_generate_secure_id(),
            name=task.name,
            description=task.description,
            task_type=getattr(task, 'task_type', 'search_keyword'),  # 兼容旧数据
            query=task.query,
            crawl_url=task.crawl_url,
            target_website=task.target_website,
            search_config=task.search_config.copy(),
            crawl_config=getattr(task, 'crawl_config', {}).copy() if hasattr(task, 'crawl_config') else {},
            schedule_interval=task.schedule_interval,
            is_active=task.is_active,
            status=task.status,
            created_by=task.created_by,
            created_at=task.created_at,
            updated_at=task.updated_at,
            last_executed_at=task.last_executed_at,
            next_run_time=task.next_run_time,
            execution_count=task.execution_count,
            success_count=task.success_count,
            failure_count=task.failure_count,
            total_results=task.total_results,
            total_credits_used=task.total_credits_used
        )
        return new_task