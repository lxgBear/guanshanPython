"""AggregatedSearchResult MongoDB Repository 实现

Version: v3.0.0 (模块化架构)

提供智能搜索聚合结果的MongoDB持久化实现。
"""

from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from motor.motor_asyncio import AsyncIOMotorDatabase

from src.core.domain.entities.aggregated_search_result import AggregatedSearchResult
from src.core.domain.entities.search_result import ResultStatus
from src.infrastructure.persistence.interfaces import IAggregatedSearchResultRepository
from src.infrastructure.persistence.exceptions import RepositoryException
from src.utils.logger import get_logger

logger = get_logger(__name__)


class MongoAggregatedSearchResultRepository(IAggregatedSearchResultRepository):
    """AggregatedSearchResult MongoDB Repository 实现

    集合名称: smart_search_results

    核心功能：
    - 存储去重聚合后的搜索结果
    - 包含综合评分、多源信息、聚合统计
    - 与 instant_search_results 分离
    - 支持多维度查询和排序
    - 提供丰富的统计分析功能
    """

    COLLECTION_NAME = "smart_search_results"

    def __init__(self, db: Optional[AsyncIOMotorDatabase] = None):
        """初始化Repository

        Args:
            db: MongoDB数据库实例，如果为None则自动获取
        """
        self._db = db
        self.collection_name = self.COLLECTION_NAME

    async def _get_collection(self):
        """获取集合"""
        if self._db is None:
            from src.infrastructure.database.connection import get_mongodb_database
            self._db = await get_mongodb_database()
        return self._db[self.collection_name]

    async def save_results(
        self,
        results: List[AggregatedSearchResult]
    ) -> int:
        """批量保存聚合搜索结果"""
        if not results:
            logger.warning("保存聚合结果: 结果列表为空")
            return 0

        try:
            documents = []
            for result in results:
                doc = result.to_dict()
                doc["_id"] = doc["id"]  # MongoDB使用 _id 作为主键
                documents.append(doc)

            await (await self._get_collection()).insert_many(documents)
            logger.info(
                f"保存聚合结果成功: task_id={results[0].smart_task_id}, "
                f"数量={len(results)}"
            )
            return len(results)

        except Exception as e:
            logger.error(f"❌ 保存聚合结果失败: {str(e)}")
            raise RepositoryException(f"保存聚合结果失败: {e}")

    async def get_results_by_task(
        self,
        smart_task_id: str,
        skip: int = 0,
        limit: int = 50,
        sort_by: str = "composite_score"
    ) -> Tuple[List[AggregatedSearchResult], int]:
        """获取任务的聚合搜索结果"""
        try:
            query = {"smart_task_id": smart_task_id}
            collection = await self._get_collection()

            # 总数
            total = await collection.count_documents(query)

            # 排序规则
            sort_fields = []
            if sort_by == "composite_score":
                sort_fields = [
                    ("composite_score", -1),
                    ("source_count", -1),
                    ("avg_relevance_score", -1)
                ]
            elif sort_by == "source_count":
                sort_fields = [("source_count", -1), ("composite_score", -1)]
            elif sort_by == "avg_relevance_score":
                sort_fields = [("avg_relevance_score", -1), ("composite_score", -1)]
            elif sort_by == "created_at":
                sort_fields = [("created_at", -1)]
            else:
                sort_fields = [("composite_score", -1)]

            # 查询
            cursor = collection.find(query).sort(sort_fields).skip(skip).limit(limit)

            results = []
            async for doc in cursor:
                results.append(AggregatedSearchResult.from_dict(doc))

            return results, total

        except Exception as e:
            logger.error(f"❌ 获取任务聚合结果失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"获取任务聚合结果失败: {e}")

    async def get_top_results(
        self,
        smart_task_id: str,
        limit: int = 10,
        min_composite_score: float = 0.0
    ) -> List[AggregatedSearchResult]:
        """获取任务的top结果（按综合评分）"""
        try:
            query = {
                "smart_task_id": smart_task_id,
                "composite_score": {"$gte": min_composite_score}
            }

            cursor = (await self._get_collection()).find(query).sort([
                ("composite_score", -1),
                ("source_count", -1),
                ("avg_relevance_score", -1)
            ]).limit(limit)

            results = []
            async for doc in cursor:
                results.append(AggregatedSearchResult.from_dict(doc))

            return results

        except Exception as e:
            logger.error(f"❌ 获取top结果失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"获取top结果失败: {e}")

    async def get_multi_source_results(
        self,
        smart_task_id: str,
        min_source_count: int = 2,
        skip: int = 0,
        limit: int = 50
    ) -> Tuple[List[AggregatedSearchResult], int]:
        """获取多源结果（出现在多个查询中）"""
        try:
            query = {
                "smart_task_id": smart_task_id,
                "source_count": {"$gte": min_source_count}
            }

            collection = await self._get_collection()

            # 总数
            total = await collection.count_documents(query)

            # 查询（按来源数量和综合评分排序）
            cursor = collection.find(query).sort([
                ("source_count", -1),
                ("composite_score", -1)
            ]).skip(skip).limit(limit)

            results = []
            async for doc in cursor:
                results.append(AggregatedSearchResult.from_dict(doc))

            return results, total

        except Exception as e:
            logger.error(f"❌ 获取多源结果失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"获取多源结果失败: {e}")

    async def count_results_by_task(self, smart_task_id: str) -> int:
        """统计任务的结果数量"""
        try:
            return await (await self._get_collection()).count_documents(
                {"smart_task_id": smart_task_id}
            )
        except Exception as e:
            logger.error(f"❌ 统计结果数量失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"统计结果数量失败: {e}")

    async def get_statistics_by_task(self, smart_task_id: str) -> Dict[str, Any]:
        """获取任务的统计信息"""
        try:
            pipeline = [
                {"$match": {"smart_task_id": smart_task_id}},
                {"$group": {
                    "_id": None,
                    "total_count": {"$sum": 1},
                    "avg_composite_score": {"$avg": "$composite_score"},
                    "avg_source_count": {"$avg": "$source_count"},
                    "max_composite_score": {"$max": "$composite_score"},
                    "min_composite_score": {"$min": "$composite_score"},
                    "multi_source_count": {
                        "$sum": {"$cond": [{"$gt": ["$source_count", 1]}, 1, 0]}
                    },
                    "single_source_count": {
                        "$sum": {"$cond": [{"$eq": ["$source_count", 1]}, 1, 0]}
                    }
                }}
            ]

            stats = None
            async for doc in (await self._get_collection()).aggregate(pipeline):
                stats = {
                    "total_results": doc["total_count"],
                    "avg_composite_score": round(doc["avg_composite_score"], 3),
                    "avg_source_count": round(doc["avg_source_count"], 2),
                    "max_composite_score": round(doc["max_composite_score"], 3),
                    "min_composite_score": round(doc["min_composite_score"], 3),
                    "multi_source_results": doc["multi_source_count"],
                    "single_source_results": doc["single_source_count"],
                    "multi_source_ratio": round(
                        doc["multi_source_count"] / doc["total_count"] * 100, 2
                    ) if doc["total_count"] > 0 else 0
                }

            return stats or {
                "total_results": 0,
                "avg_composite_score": 0,
                "avg_source_count": 0,
                "max_composite_score": 0,
                "min_composite_score": 0,
                "multi_source_results": 0,
                "single_source_results": 0,
                "multi_source_ratio": 0
            }

        except Exception as e:
            logger.error(f"❌ 获取统计信息失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"获取统计信息失败: {e}")

    async def delete_results_by_task(self, smart_task_id: str) -> int:
        """删除任务的所有结果"""
        try:
            result = await (await self._get_collection()).delete_many(
                {"smart_task_id": smart_task_id}
            )
            logger.info(
                f"删除聚合结果: task_id={smart_task_id}, "
                f"删除数量={result.deleted_count}"
            )
            return result.deleted_count

        except Exception as e:
            logger.error(f"❌ 删除聚合结果失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"删除聚合结果失败: {e}")

    async def update_result(self, result: AggregatedSearchResult) -> bool:
        """更新单个结果"""
        try:
            result.updated_at = datetime.utcnow()
            doc = result.to_dict()

            update_result = await (await self._get_collection()).update_one(
                {"_id": result.id},
                {"$set": doc}
            )

            return update_result.modified_count > 0

        except Exception as e:
            logger.error(f"❌ 更新结果失败: {result.id}, 错误: {e}")
            raise RepositoryException(f"更新结果失败: {e}")

    async def get_by_url(
        self,
        smart_task_id: str,
        url: str
    ) -> Optional[AggregatedSearchResult]:
        """根据URL查找结果（去重时使用）"""
        try:
            doc = await (await self._get_collection()).find_one({
                "smart_task_id": smart_task_id,
                "url": url
            })

            return AggregatedSearchResult.from_dict(doc) if doc else None

        except Exception as e:
            logger.error(f"❌ 根据URL查找结果失败: {url}, 错误: {e}")
            raise RepositoryException(f"根据URL查找结果失败: {e}")

    # ==================== 状态管理方法 ====================

    async def get_results_by_status(
        self,
        smart_task_id: str,
        status: ResultStatus,
        skip: int = 0,
        limit: int = 50
    ) -> Tuple[List[AggregatedSearchResult], int]:
        """按状态筛选结果"""
        try:
            query = {
                "smart_task_id": smart_task_id,
                "status": status.value
            }

            collection = await self._get_collection()

            # 总数
            total = await collection.count_documents(query)

            # 查询
            cursor = collection.find(query).sort([
                ("composite_score", -1),
                ("created_at", -1)
            ]).skip(skip).limit(limit)

            results = []
            async for doc in cursor:
                results.append(AggregatedSearchResult.from_dict(doc))

            return results, total

        except Exception as e:
            logger.error(f"❌ 按状态查询结果失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"按状态查询结果失败: {e}")

    async def count_by_status(self, smart_task_id: str) -> Dict[str, int]:
        """统计各状态结果数量"""
        try:
            pipeline = [
                {"$match": {"smart_task_id": smart_task_id}},
                {"$group": {
                    "_id": "$status",
                    "count": {"$sum": 1}
                }}
            ]

            status_counts = {status.value: 0 for status in ResultStatus}

            async for doc in (await self._get_collection()).aggregate(pipeline):
                status_counts[doc["_id"]] = doc["count"]

            return status_counts

        except Exception as e:
            logger.error(f"❌ 统计状态数量失败: {smart_task_id}, 错误: {e}")
            raise RepositoryException(f"统计状态数量失败: {e}")

    async def update_result_status(
        self,
        result_id: str,
        new_status: ResultStatus
    ) -> bool:
        """更新单个结果状态"""
        try:
            update_data = {
                "status": new_status.value,
                "updated_at": datetime.utcnow()
            }

            result = await (await self._get_collection()).update_one(
                {"_id": result_id},
                {"$set": update_data}
            )

            return result.modified_count > 0

        except Exception as e:
            logger.error(f"❌ 更新结果状态失败: {result_id}, 错误: {e}")
            raise RepositoryException(f"更新结果状态失败: {e}")

    async def bulk_update_status(
        self,
        result_ids: List[str],
        new_status: ResultStatus
    ) -> int:
        """批量更新结果状态"""
        try:
            update_data = {
                "status": new_status.value,
                "updated_at": datetime.utcnow()
            }

            result = await (await self._get_collection()).update_many(
                {"_id": {"$in": result_ids}},
                {"$set": update_data}
            )

            return result.modified_count

        except Exception as e:
            logger.error(f"❌ 批量更新状态失败, 错误: {e}")
            raise RepositoryException(f"批量更新状态失败: {e}")

    # ==================== IBasicRepository 基础方法 ====================

    async def create(self, entity: AggregatedSearchResult) -> str:
        """创建聚合搜索结果

        Args:
            entity: 聚合搜索结果实体

        Returns:
            str: 创建成功后的实体ID

        Raises:
            RepositoryException: 创建失败时抛出
        """
        try:
            doc = entity.to_dict()
            doc["_id"] = entity.id  # MongoDB使用 _id 作为主键

            await (await self._get_collection()).insert_one(doc)
            logger.info(f"✅ 创建聚合搜索结果成功: {entity.id}")
            return entity.id

        except Exception as e:
            logger.error(f"❌ 创建聚合搜索结果失败: {entity.id}, 错误: {e}")
            raise RepositoryException(f"创建聚合搜索结果失败: {e}")

    async def get_by_id(self, id: str) -> Optional[AggregatedSearchResult]:
        """根据ID获取聚合搜索结果

        Args:
            id: 实体ID

        Returns:
            Optional[AggregatedSearchResult]: 实体对象，如果不存在则返回 None

        Raises:
            RepositoryException: 查询失败时抛出
        """
        try:
            doc = await (await self._get_collection()).find_one({"_id": id})
            return AggregatedSearchResult.from_dict(doc) if doc else None

        except Exception as e:
            logger.error(f"❌ 根据ID获取聚合搜索结果失败: {id}, 错误: {e}")
            raise RepositoryException(f"根据ID获取聚合搜索结果失败: {e}")

    async def update(self, entity: AggregatedSearchResult) -> bool:
        """更新聚合搜索结果

        Args:
            entity: 要更新的聚合搜索结果实体（必须包含有效的 ID）

        Returns:
            bool: 更新是否成功

        Raises:
            RepositoryException: 更新失败时抛出
        """
        try:
            entity.updated_at = datetime.utcnow()
            doc = entity.to_dict()

            result = await (await self._get_collection()).update_one(
                {"_id": entity.id},
                {"$set": doc}
            )

            return result.modified_count > 0

        except Exception as e:
            logger.error(f"❌ 更新聚合搜索结果失败: {entity.id}, 错误: {e}")
            raise RepositoryException(f"更新聚合搜索结果失败: {e}")

    async def delete(self, id: str) -> bool:
        """删除聚合搜索结果

        Args:
            id: 要删除的实体ID

        Returns:
            bool: 删除是否成功

        Raises:
            RepositoryException: 删除失败时抛出
        """
        try:
            result = await (await self._get_collection()).delete_one({"_id": id})
            logger.info(f"删除聚合搜索结果: {id}, 删除数量={result.deleted_count}")
            return result.deleted_count > 0

        except Exception as e:
            logger.error(f"❌ 删除聚合搜索结果失败: {id}, 错误: {e}")
            raise RepositoryException(f"删除聚合搜索结果失败: {e}")

    async def exists(self, id: str) -> bool:
        """检查聚合搜索结果是否存在

        Args:
            id: 实体ID

        Returns:
            bool: 实体是否存在

        Raises:
            RepositoryException: 查询失败时抛出
        """
        try:
            count = await (await self._get_collection()).count_documents({"_id": id})
            return count > 0

        except Exception as e:
            logger.error(f"❌ 检查聚合搜索结果是否存在失败: {id}, 错误: {e}")
            raise RepositoryException(f"检查聚合搜索结果是否存在失败: {e}")
