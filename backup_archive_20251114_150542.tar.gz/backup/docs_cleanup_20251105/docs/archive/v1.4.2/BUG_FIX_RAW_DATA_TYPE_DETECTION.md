# Bug修复文档 - 原始数据类型检测和日志增强

**修复日期**: 2025-10-31
**版本**: v1.4.2
**严重程度**: 高
**影响范围**: 数据源管理API - 添加/移除原始数据端点

**🔔 重要提示**: 本文档描述的智能ID检测方案已被 **v1.5.0 ID系统统一** 取代。
- v1.4.2 使用智能检测作为临时修复方案
- v1.5.0 统一所有ID为雪花算法，从根本上解决了问题
- 详见：`frontend-types/ID_SYSTEM_UNIFICATION_v1.5.0.md`

---

## 问题概述

### 问题1：raw-data接口400错误无日志详情

**现象**: `/api/v1/data-sources/{id}/raw-data` 端点返回 400 错误，但日志中只有 HTTP 状态码，无错误详情。

**影响**:
- 生产环境出现8次连续400错误（2025-10-31 14:50:54）
- 无法定位具体错误原因
- 运维和开发调试困难

**根本原因**:
- API 端点捕获 `ValueError` 后直接抛出 `HTTPException`
- 未在抛出异常前记录日志
- 代码位置：`src/api/v1/endpoints/data_source_management.py` 第237-238行

### 问题2：前端data_type与data_id不匹配

**现象**: 前端发送请求时，`data_type` 字段与 `data_id` 格式不一致。

**错误请求示例**:
```json
{
  "data_id": "7c2a1e9e-e92e-4325-bd81-c8c3e29df0c5",  // UUID格式
  "data_type": "instant",                              // 声称是instant类型
  "source_task_id": "0b75c1a7-2fc0-58a8-8ee6-6dcebe4d85d3",
  "added_by": "current_user"
}
```

**实际错误**:
```
Raw data '7c2a1e9e-e92e-4325-bd81-c8c3e29df0c5' not found in instant collection
```

**根本原因**:
- **scheduled类型** (定时搜索): 使用 UUID 格式 ID，存储在 `search_results` 集合
- **instant类型** (即时搜索): 使用雪花算法 ID（纯数字字符串），存储在 `instant_search_results` 集合
- 前端错误地将 UUID 格式的 ID 声明为 `instant` 类型
- 后端未做防御性校验，直接按前端声明的类型查询错误的集合

---

## 修复方案

### 修复1：添加详细错误日志

#### 代码修改

**文件**: `src/api/v1/endpoints/data_source_management.py`

**修改位置**: 添加原始数据端点 (第237-238行)

```python
# 修复前
except ValueError as e:
    raise HTTPException(status_code=400, detail=str(e))

# 修复后
except ValueError as e:
    logger.warning(
        f"添加原始数据业务逻辑错误: {str(e)} "
        f"(data_source_id={data_source_id}, data_id={request.data_id}, data_type={request.data_type})"
    )
    raise HTTPException(status_code=400, detail=str(e))
```

**改进效果**:
- ✅ 记录完整的错误上下文（数据源ID、数据ID、数据类型）
- ✅ 使用 WARNING 级别（业务逻辑错误，非系统错误）
- ✅ 便于生产环境问题追踪和定位

### 修复2：智能ID格式检测和类型纠正

#### 技术方案

实现防御性编程策略，在服务层自动检测 ID 格式并纠正 `data_type`。

| ID 格式 | 检测规则 | 实际类型 | 集合 | 示例 |
|---------|---------|---------|------|------|
| UUID | 包含横杠 `-` | `scheduled` | `search_results` | `7c2a1e9e-e92e-4325-bd81-c8c3e29df0c5` |
| 雪花ID | 纯数字字符串 | `instant` | `instant_search_results` | `242540877529686016` |

#### 代码修改

**文件**: `src/services/data_curation_service.py`

**修改2.1**: 添加智能检测辅助方法 (第956-978行)

```python
def _detect_data_type_from_id(self, data_id: str) -> str:
    """智能检测数据ID类型

    规则：
    - UUID格式（包含横杠，如 7c2a1e9e-e92e-4325-bd81-c8c3e29df0c5）→ scheduled
    - 纯数字字符串（雪花ID，如 242540877529686016）→ instant

    Args:
        data_id: 数据ID

    Returns:
        数据类型：'scheduled' 或 'instant'
    """
    if '-' in data_id:
        # UUID格式：包含横杠
        return "scheduled"
    elif data_id.isdigit():
        # 雪花ID格式：纯数字字符串
        return "instant"
    else:
        # 未知格式，默认为instant（新系统）
        logger.warning(f"⚠️  未知ID格式，默认为instant: {data_id}")
        return "instant"
```

**修改2.2**: `add_raw_data_to_source` 方法添加类型纠正 (第306-315行)

```python
# 🛡️ 智能ID格式检测和类型纠正（防御性编程）
# UUID格式（带横杠）→ scheduled
# 纯数字字符串（雪花ID）→ instant
actual_data_type = self._detect_data_type_from_id(data_id)
if actual_data_type != data_type:
    logger.warning(
        f"⚠️  数据类型自动纠正: data_id={data_id}, "
        f"前端声明={data_type}, 实际检测={actual_data_type}"
    )
    data_type = actual_data_type
```

**修改2.3**: `remove_raw_data_from_source` 方法同样添加 (第431-438行)

保持一致性，移除操作也应用相同的智能检测逻辑。

---

## 影响范围分析

### 修改的文件

1. ✅ `src/api/v1/endpoints/data_source_management.py` - API层错误日志
2. ✅ `src/services/data_curation_service.py` - 服务层智能检测

### 未修改的文件

- ✅ `src/core/domain/entities/data_source.py` - Domain层无需修改
- ✅ `src/infrastructure/database/data_source_repositories.py` - 仓储层无需修改

### 向后兼容性

✅ **完全向后兼容**:
- 智能检测不破坏正确的请求（类型匹配时直接通过）
- 只在类型不匹配时自动纠正，并记录警告日志
- 前端正确实现后，警告日志自然消失

---

## 测试验证

### 测试场景1：UUID格式ID被错误标记为instant

**请求**:
```json
{
  "data_id": "7c2a1e9e-e92e-4325-bd81-c8c3e29df0c5",
  "data_type": "instant",
  "added_by": "test_user"
}
```

**预期行为**:
1. 后端检测到 UUID 格式（包含横杠）
2. 自动纠正 `data_type` 为 `scheduled`
3. 记录警告日志：
   ```
   WARNING - ⚠️  数据类型自动纠正: data_id=7c2a1e9e-e92e-4325-bd81-c8c3e29df0c5, 前端声明=instant, 实际检测=scheduled
   ```
4. 在 `search_results` 集合中查询数据
5. 如果数据存在且状态正确，添加成功

### 测试场景2：雪花ID格式ID被错误标记为scheduled

**请求**:
```json
{
  "data_id": "242540877529686016",
  "data_type": "scheduled",
  "added_by": "test_user"
}
```

**预期行为**:
1. 后端检测到雪花ID格式（纯数字）
2. 自动纠正 `data_type` 为 `instant`
3. 记录警告日志
4. 在 `instant_search_results` 集合中查询数据

### 测试场景3：正确的请求（无纠正）

**请求**:
```json
{
  "data_id": "242540877529686016",
  "data_type": "instant",
  "added_by": "test_user"
}
```

**预期行为**:
1. 检测到类型匹配，直接通过
2. 不记录警告日志
3. 正常查询和处理

### 测试场景4：数据不存在错误日志

**请求**: 尝试添加不存在的数据ID

**预期日志**:
```
WARNING - 添加原始数据业务逻辑错误: Raw data 'xxx' not found in instant collection (data_source_id=242540877529686016, data_id=xxx, data_type=instant)
```

---

## 部署说明

### 部署步骤

1. **代码部署**: 将修改后的文件部署到生产环境
2. **服务重启**: uvicorn 已启用 `--reload`，修改后自动重启（进程ID: 40027）
3. **验证测试**: 监控日志，观察类型纠正警告

### 监控要点

**关键日志监控**:
```bash
# 监控类型纠正日志
grep "数据类型自动纠正" logs/fastapi.log

# 监控业务逻辑错误
grep "添加原始数据业务逻辑错误" logs/fastapi.log
```

**预期结果**:
- 短期内可能出现类型纠正警告（前端未修复时）
- 数据添加操作成功率提升
- 错误日志包含完整上下文信息

### 回滚方案

如果出现问题，可以回滚到修改前的版本：
- 移除 `_detect_data_type_from_id` 方法
- 移除智能检测逻辑
- 恢复原始的异常处理（无日志）

---

## 长期改进建议

### 前端修复 (推荐)

**根本解决方案**: 前端正确识别和发送数据类型

```typescript
// 前端ID格式检测函数
function detectDataType(dataId: string): 'scheduled' | 'instant' {
  if (dataId.includes('-')) {
    // UUID格式 → scheduled
    return 'scheduled';
  } else if (/^\d+$/.test(dataId)) {
    // 纯数字 → instant
    return 'instant';
  }
  // 默认instant（新系统）
  return 'instant';
}

// 使用示例
const dataType = detectDataType(selectedData.id);
const request = {
  data_id: selectedData.id,
  data_type: dataType,  // 自动检测，不依赖前端手动选择
  added_by: currentUser
};
```

### API 文档更新

在 OpenAPI 文档中明确说明：
```markdown
**data_id 格式规范**:
- scheduled类型: UUID格式 (包含横杠，如 `7c2a1e9e-e92e-4325-bd81-c8c3e29df0c5`)
- instant类型: 雪花ID格式 (纯数字字符串，如 `242540877529686016`)

**注意**: 后端会自动检测ID格式并纠正data_type，建议前端主动实现检测逻辑。
```

### 统一ID系统 (未来架构改进)

**长期目标**: 迁移所有系统到雪花算法 ID

- 优势：全局唯一、时间有序、分布式友好
- 迁移策略：保留 UUID 兼容性，新数据使用雪花ID
- 过渡期：继续使用智能检测逻辑

---

## 相关文档

- [数据源管理系统架构](SYSTEM_ARCHITECTURE.md)
- [数据源整编后端文档](DATA_SOURCE_CURATION_BACKEND.md)
- [空数据源确认修复](BUG_FIX_EMPTY_DATASOURCE_CONFIRM.md)

---

## 变更记录

| 日期 | 版本 | 修改内容 | 修改人 |
|------|------|---------|--------|
| 2025-10-31 | v1.4.2 | 添加错误日志和智能ID检测 | Claude |
