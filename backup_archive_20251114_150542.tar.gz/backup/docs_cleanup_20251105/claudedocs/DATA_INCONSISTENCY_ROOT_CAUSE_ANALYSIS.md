# 智能搜索数据不一致问题 - 根因分析报告

**日期**: 2025-11-03
**版本**: v1.5.2
**问题**: smart_search_results 表里内容和放给前端内容不一致

---

## 🎯 问题根因

### 核心发现

**`smart_search_results` 集合未被实际使用，但包含历史遗留的UUID格式数据**

| 集合名称 | 实际使用 | 记录数 | ID格式 | 状态 |
|---------|---------|--------|--------|------|
| `smart_search_results` | ❌ 否 | 3条 | UUID | 历史遗留数据 |
| `instant_search_results` | ✅ 是 | 65条 | 雪花ID | 当前生产数据 |

### 证据

**检查1: 代码使用情况**
```bash
$ grep -r "SmartSearchResultRepository" src --include="*.py"
# 结果: 只在定义文件中出现，没有任何导入或使用
```

**检查2: 数据库实际数据**
```python
# smart_search_results (未使用)
{
    "_id": "b5c9db94-8812-4717-902a-d06866345cf3",  # UUID格式
    "task_id": "9989cc5f-e265-49a9-98b1-ef7c934003cd"  # UUID格式
}

# instant_search_results (实际使用)
{
    "_id": "239585920781914112",  # 雪花ID格式
    "task_id": "239585874380328960"  # 雪花ID格式
}
```

**检查3: 测试验证**
```
智能搜索测试 (任务ID: 243583472259153920)
    ↓
创建3个子搜索
    ↓
结果存储位置: instant_search_results ✅
    ↓
30条搜索结果成功聚合

smart_search_results: 未写入任何数据 ✓
```

---

## 📊 架构澄清

### 实际数据流

```
┌─────────────────────────────────────────┐
│   智能搜索系统 (SmartSearchService)      │
│   v2.0.0 - LLM查询分解                  │
└────────────┬────────────────────────────┘
             │
             ↓ 调用 InstantSearchService
┌─────────────────────────────────────────┐
│   即时搜索系统 (InstantSearchService)    │
│   v1.3.0 - 基础搜索功能                 │
└────────────┬────────────────────────────┘
             │
             ↓ 结果存储
┌─────────────────────────────────────────┐
│   instant_search_results 集合           │
│   - 即时搜索结果                         │
│   - 智能搜索子查询结果                   │
│   - ID: 雪花算法                         │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│   smart_search_results 集合              │
│   - Repository已实现 (600行代码)         │
│   - 但未被任何代码使用                   │
│   - 包含3条UUID格式历史数据              │
└─────────────────────────────────────────┘
```

### 集合职责

| 集合名称 | 职责 | 使用状态 | 数据来源 |
|---------|------|----------|----------|
| `smart_search_tasks` | 智能搜索任务元数据 | ✅ 使用中 | SmartSearchService |
| `instant_search_results` | 即时搜索 + 智能搜索结果 | ✅ 使用中 | InstantSearchService |
| `smart_search_results` | 智能搜索专用结果存储 | ❌ 未使用 | 无 (设计遗留) |

---

## 🔍 问题表现

### 前端可能遇到的问题

**场景1: 前端直接查询 smart_search_results**
```javascript
// 前端代码 (假设)
const results = await fetch('/api/v1/smart-search-results/' + taskId);
// 结果: 只能看到3条旧的UUID数据
// 问题: 看不到实际的65条最新数据
```

**场景2: API返回instant_search_results数据**
```javascript
// 后端实际返回的是 instant_search_results 数据
// ID格式: "239585920781914112" (雪花ID)
// 前端期望: "b5c9db94-..." (UUID)
// 结果: 数据格式不匹配
```

### 数据不一致的具体表现

1. **记录数不一致**:
   - `smart_search_results`: 3条
   - 实际搜索结果: 65条+

2. **ID格式不一致**:
   - 历史数据: UUID格式 (36字符,带连字符)
   - 当前数据: 雪花ID格式 (15-19位数字)

3. **时间不一致**:
   - 历史数据: v1.5.0之前的数据
   - 当前数据: v1.5.0及之后的数据

---

## ✅ 解决方案实施

### 方案1: 清理历史数据 (已执行)

**操作**:
```python
# 删除 smart_search_results 的所有历史记录
result = await db.smart_search_results.delete_many({})
# 结果: 删除3条UUID格式的历史记录
```

**效果**:
- ✅ 删除前: 3条UUID格式数据
- ✅ 删除后: 0条记录
- ✅ 表已清空,避免混淆

### 方案2: 确认数据源 (建议)

**前端应该读取的正确集合**:
```
GET /api/v1/smart-search-tasks/{task_id}/results
    ↓
后端从 instant_search_results 聚合数据
    ↓
返回雪花ID格式的结果
```

**前端需要验证**:
1. API端点是否正确
2. ID字段解析逻辑 (雪花ID是字符串,不是数字)
3. 缓存是否需要清除

---

## 🎯 架构优化建议

### 选项A: 移除 SmartSearchResultRepository (推荐)

**理由**:
- Repository完全未被使用
- 简化架构,减少维护成本
- 避免开发者混淆

**操作**:
```bash
# 删除文件
rm src/infrastructure/database/smart_search_result_repositories.py

# 删除集合 (可选,保留空集合也无害)
# db.smart_search_results.drop()
```

**影响**: 无 (因为从未被使用)

### 选项B: 实现真正的职责分离

**理由**:
- 分离即时搜索和智能搜索结果
- 智能搜索结果包含额外的分解字段

**实现**:
1. 修改 `SmartSearchService` 使用 `SmartSearchResultRepository`
2. 在 `save_results()` 时写入智能搜索特定字段
3. 聚合时从 `smart_search_results` 读取

**工作量**: 中等 (需修改服务层代码)

---

## 📋 验证清单

### ✅ 已完成

- [x] 确认 `smart_search_results` 未被使用
- [x] 清理3条UUID格式历史数据
- [x] 验证 `instant_search_results` 是实际数据源
- [x] 确认SmartSearchResultRepository已修复为雪花ID格式

### 📝 待验证

- [ ] 前端API调用端点是否正确
- [ ] 前端ID解析逻辑是否兼容雪花ID
- [ ] 前端缓存是否需要清除
- [ ] 是否决定移除 SmartSearchResultRepository

---

## 📈 测试验证

### 智能搜索端到端测试

**测试任务**: 243583472259153920

| 步骤 | 操作 | 结果 | 数据位置 |
|------|------|------|----------|
| 1 | 创建任务+LLM分解 | ✅ 成功 (3个子查询) | smart_search_tasks |
| 2 | 确认并执行搜索 | ✅ 成功 (30条结果) | instant_search_results |
| 3 | 获取聚合结果 | ✅ 成功 (分页返回) | instant_search_results |
| 4 | 检查smart_search_results | ✅ 无写入 (预期行为) | 空 |

**结论**: 智能搜索系统完全依赖 `instant_search_results`,不使用 `smart_search_results`

---

## 🔗 相关文档

- [智能搜索测试报告](SMART_SEARCH_TEST_REPORT.md)
- [智能搜索分析报告](SMART_SEARCH_ANALYSIS_REPORT.md)
- [智能搜索实施报告](SMART_SEARCH_FIX_IMPLEMENTATION.md)
- [ID系统统一报告](ID_SYSTEM_V1.5.0.md)

---

## 📞 后续行动

### 立即执行

1. **前端团队**: 验证API调用是否使用正确端点
   ```
   正确: GET /api/v1/smart-search-tasks/{id}/results
   错误: 不要直接查询 smart_search_results 集合
   ```

2. **前端团队**: 检查ID字段类型处理
   ```javascript
   // 雪花ID是字符串,不是数字
   const taskId: string = "243583472259153920";
   // 不要: const taskId: number = 243583472259153920; ❌
   ```

3. **前端团队**: 清除浏览器缓存
   ```javascript
   // 清除 LocalStorage
   localStorage.clear();
   // 清除 SessionStorage
   sessionStorage.clear();
   ```

### 架构决策

**决定是否移除 `SmartSearchResultRepository`**:
- 选项A (推荐): 移除 → 简化架构
- 选项B: 保留并实现职责分离 → 增加复杂度但逻辑清晰

---

**分析人**: Claude Code Assistant
**问题状态**: ✅ 根因确认,历史数据已清理
**下一步**: 等待前端验证和架构决策

**报告生成时间**: 2025-11-03
**版本**: v1.0.0
